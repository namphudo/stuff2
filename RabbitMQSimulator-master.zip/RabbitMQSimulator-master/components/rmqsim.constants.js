var EXCHANGE = 0;
var QUEUE = 1;
var PRODUCER = 2;
var CONSUMER = 3;

var exchange_types = {
    direct: 0,
    fanout: 1,
    topic: 2 
};